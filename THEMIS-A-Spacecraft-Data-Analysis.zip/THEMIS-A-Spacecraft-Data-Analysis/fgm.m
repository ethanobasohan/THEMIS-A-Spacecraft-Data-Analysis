% THEMIS-A Magnetic Field
% June 10-12, 2014

clear;
clc;
close all;

% The three FGM files
files = {
    'tha_l2_fgm_20140610_v01.cdf'
    'tha_l2_fgm_20140611_v01.cdf'
    'tha_l2_fgm_20140612_v01.cdf'
    };

% Storage for all three days
allTime = [];
allField = [];

% Read each day
for i = 1:length(files)

    % Read FGS time
    timeData = cdfread(files{i}, ...
        'Variables', {'tha_fgs_time'}, ...
        'CombineRecords', true);

    % Read magnetic field in GSM coordinates
    fieldData = cdfread(files{i}, ...
        'Variables', {'tha_fgs_gsm'}, ...
        'CombineRecords', true);

    % Combine the days
    allTime = [allTime; timeData(:)];
    allField = [allField; fieldData];

end

% Separate the three magnetic-field components
Bx = allField(:,1);
By = allField(:,2);
Bz = allField(:,3);

% Convert time to UTC
timeUTC = datetime(allTime, ...
    'ConvertFrom', 'posixtime', ...
    'TimeZone', 'UTC');

% Plot
figure;

plot(timeUTC, Bx, 'LineWidth', 1);
hold on;
plot(timeUTC, By, 'LineWidth', 1);
plot(timeUTC, Bz, 'LineWidth', 1);
hold off;

xlabel('Time (UTC)');
ylabel('Magnetic Field (nT)');
title('THEMIS-A GSM Magnetic Field: June 10-12, 2014');
legend('Bx GSM', 'By GSM', 'Bz GSM');
grid on;