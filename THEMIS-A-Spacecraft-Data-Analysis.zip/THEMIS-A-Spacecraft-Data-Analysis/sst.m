% THEMIS-A SST Ion Energy Flux
% June 10-12, 2014

clear;
clc;
close all;

% The three SST files
files = {
    'tha_l2_sst_20140610_v01.cdf'
    'tha_l2_sst_20140611_v01.cdf'
    'tha_l2_sst_20140612_v01.cdf'
    };

% Storage for all three days
allTime = [];
allFlux = [];
allEnergy = [];

% Read each day
for i = 1:length(files)

    % Read ion time
    timeData = cdfread(files{i}, ...
        'Variables', {'tha_psif_time'}, ...
        'CombineRecords', true);

    % Read ion energy flux
    fluxData = cdfread(files{i}, ...
        'Variables', {'tha_psif_en_eflux'}, ...
        'CombineRecords', true);

    % Read ion energy channels
    energyData = cdfread(files{i}, ...
        'Variables', {'tha_psif_en_eflux_yaxis'}, ...
        'CombineRecords', true);

    % Keep only the 12 usable channels
    fluxData = fluxData(:, 1:12);
    energyData = energyData(:, 1:12);

    % Add this day to the combined data
    allTime = [allTime; timeData(:)];
    allFlux = [allFlux; fluxData];
    allEnergy = [allEnergy; energyData];

end

% TEST: Check whether the energy channels change over time
disp('Minimum energy values for each channel:')
disp(min(allEnergy, [], 1, 'omitnan'))

disp('Maximum energy values for each channel:')
disp(max(allEnergy, [], 1, 'omitnan'))

% Convert Unix time to UTC
timeUTC = datetime(allTime, ...
    'ConvertFrom', 'posixtime', ...
    'TimeZone', 'UTC');

% Find a row containing valid energy values
validRow = find(all(~isnan(allEnergy), 2), 1);

% Energy axis is stored in eV
% Convert eV to keV
energy = allEnergy(validRow, :) / 1000;

% Plot the three days
figure;

imagesc(timeUTC, energy, log10(allFlux'));

axis xy;

xlabel('Time (UTC)');
ylabel('Energy (keV)');
title('THEMIS-A SST Ion Energy Flux: June 10-12, 2014');

c = colorbar;
c.Label.String = 'log_{10}(Energy Flux)';

grid on;