% THEMIS-A Spacecraft Position
% June 10-12, 2014

clear;
clc;
close all;

files = {
    'tha_l1_state_20140610_v02.cdf'
    'tha_l1_state_20140611_v02.cdf'
    'tha_l1_state_20140612_v02.cdf'
    };

allTime = [];
allPosition = [];

for i = 1:length(files)

    % Read spacecraft time
    timeData = cdfread(files{i}, ...
        'Variables', {'tha_state_time'}, ...
        'CombineRecords', true);

    % Read GSM position
    positionData = cdfread(files{i}, ...
        'Variables', {'tha_pos_gsm'}, ...
        'CombineRecords', true);

    % Pull numeric arrays out of cells
    time = timeData;
    position = positionData;

    % Combine the three days
    allTime = [allTime; time(:)];
    allPosition = [allPosition; position];

end

% Separate GSM coordinates
X = allPosition(:,1);
Y = allPosition(:,2);
Z = allPosition(:,3);

% Convert THEMIS time into MATLAB datetime.
% tha_state_time is Unix/epoch time: seconds since Jan 1, 1970.
timeUTC = datetime(allTime, ...
    'ConvertFrom', 'posixtime', ...
    'TimeZone', 'UTC');

% Plot
figure;

plot(timeUTC, X, 'LineWidth', 1.2);
hold on;

plot(timeUTC, Y, 'LineWidth', 1.2);
plot(timeUTC, Z, 'LineWidth', 1.2);

hold off;

xlabel('Time (UTC)');
ylabel('Position (km)');

title('THEMIS-A GSM Position: June 10-12, 2014');

legend('X GSM', 'Y GSM', 'Z GSM');

grid on;